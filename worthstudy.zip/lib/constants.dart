import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xFFAED581);
const kPrimaryLightColor = Color(0xFFF1E6FF);

const double defaultPadding = 16.0;