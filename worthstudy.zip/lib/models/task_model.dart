class TaskM {
  String title;
  bool complete;


  TaskM(this.title, this.complete);
}