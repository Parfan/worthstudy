class User {
  String username;

  User({required this.username});
}